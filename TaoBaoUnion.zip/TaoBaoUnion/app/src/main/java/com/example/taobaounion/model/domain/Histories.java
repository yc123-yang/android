package com.example.taobaounion.model.domain;

import java.util.List;

public class Histories {
    private List<String> histories;

    public List<String> getHistories() {
        return histories;
    }

    public void setHistories(List<String> histories) {
        this.histories = histories;
    }
}
