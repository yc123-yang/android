package com.example.taobaounion.ui.activity;

public interface IMainActivity {

    void switch2Search();

}
